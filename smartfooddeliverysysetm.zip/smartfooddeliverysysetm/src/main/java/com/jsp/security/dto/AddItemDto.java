package com.jsp.security.dto;

import jakarta.validation.constraints.NotNull;

public class AddItemDto {

	@NotNull
	private String  foodName;
	@NotNull
	private double price;
	@NotNull
	private int quantity;
	public AddItemDto(@NotNull String foodName, @NotNull double price, @NotNull int quantity) {
		super();
		this.foodName = foodName;
		this.price = price;
		this.quantity = quantity;
	}
	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
	
}
