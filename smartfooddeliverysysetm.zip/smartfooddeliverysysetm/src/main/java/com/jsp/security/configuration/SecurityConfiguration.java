package com.jsp.security.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration {

	
	@Bean
	public SecurityFilterChain secure(HttpSecurity http) {
		
		http.csrf(c->c.disable());
		http.authorizeHttpRequests(r->r.requestMatchers("/home").permitAll()
				                       .requestMatchers("/WEB-INF/views/index.jsp").permitAll()
//				                       .requestMatchers("/css/index.css").permitAll()
				                       .requestMatchers("/css/**").permitAll()
				                       .requestMatchers("/WEB-INF/views/register.jsp").permitAll()
//				                       .requestMatchers("/css/register.css").permitAll()
				                       .requestMatchers("/auth/register").permitAll()
				                       .requestMatchers("/auth/foodlogin").permitAll()
				                       .requestMatchers("/auth/mylogin").permitAll()
				                       .requestMatchers("/WEB-INF/views/foodlogin.jsp").permitAll()
//				                       .requestMatchers("/css/mylogin.css").permitAll()
				                       .requestMatchers("/customer/dashboard").hasRole("USER")
				                       .requestMatchers("/restrauant/dashboard").hasRole("RESTAURANT")
				                       .requestMatchers("/delivery/dashboard").hasRole("DELIVERY_AGENT")
				                       .requestMatchers("/profile").hasAnyRole(
				                    		    "USER", "RESTAURANT", "DELIVERY_AGENT"
				                    		)
				             
				                       .requestMatchers("/css/profile.css").permitAll()
				                       .anyRequest().authenticated()
				
				);
		
		http.formLogin(form -> form.disable());
		
//		http.formLogin(	
//						form->form.loginPage("/foodlogin")
//						          .loginProcessingUrl("/login")
//						);
		
		return http.build();
		
	}
	
	@Bean
	public AuthenticationManager authenticationManager(
	        AuthenticationConfiguration configuration) throws Exception {
	    return configuration.getAuthenticationManager();
	}
}
