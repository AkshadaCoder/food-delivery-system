package com.jsp.security.service;

import java.util.Optional;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.jsp.security.entity.Users;
import com.jsp.security.repositry.UserRepo;

@Service
public class CustomUserDetailService implements UserDetailsService{

	private UserRepo repo;
	
	

	
	public CustomUserDetailService(UserRepo repo) {
		super();
		this.repo = repo;
	}




	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		Optional<Users> op=repo.findByEmail(username);
		if(op.get()==null) {
			throw new UsernameNotFoundException("User not exist");
		}
		
		return new CustomUserDetail(op.get());
	}

}
