package com.jsp.security.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;

public class RegisterRequestDto {

	@NotNull
	private String name;
	@NotNull
	@Email
	private String email;
	@NotNull
	private long phone;
	@NotNull
	private String role;
	@NotNull
	private String password;
	@NotNull
	private String confirmPassword;
	public RegisterRequestDto(@NotNull String name, @NotNull @Email String email, @NotNull long phone,
			@NotNull String role, @NotNull String password, @NotNull String confirmPassword) {
		super();
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.role = role;
		this.password = password;
		this.confirmPassword = confirmPassword;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	
	
	
	
	
	
	
}
