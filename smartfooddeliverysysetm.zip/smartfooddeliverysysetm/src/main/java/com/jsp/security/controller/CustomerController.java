package com.jsp.security.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.jsp.security.dto.AddItemDto;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/customer")
public class CustomerController {

	
	
	@GetMapping("/dashboard")
	public String customer() {
		return "customer-dashboard";
	}
	
	
	
	  @GetMapping("/restaurants")
	  public String getRestaurants(
	            @RequestParam("category") String category,
	            Model model) {

	        System.out.println("Selected category: " + category);

	        model.addAttribute("category", category);

	        return category;
	    }
	  
//	  public String addItem(@Valid @ModelAttribute AddItemDto dto) 
//	  {
//		  
//		  return ""
//		  
//	  }
	
	
	
}
