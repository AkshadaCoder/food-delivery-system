package com.jsp.security.service;

import java.util.Optional;


import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.jsp.security.dto.LoginRequestDto;
import com.jsp.security.dto.RegisterRequestDto;
import com.jsp.security.entity.Users;
import com.jsp.security.repositry.UserRepo;

@Service
public class UserRegisterServiceImpl implements UserRegisterService {

	
	private PasswordEncoder encoder;
	private UserRepo repo;
	
	
	
	public UserRegisterServiceImpl(PasswordEncoder encoder, UserRepo repo) {
		super();
		this.encoder = encoder;
		this.repo = repo;
	}



	@Override
	public boolean register(RegisterRequestDto dto) {
		Optional<Users> user=repo.findByEmail(dto.getEmail());
		if(user.isPresent()) {
			return false;
		}
		
		
		
		
		Users u1=new Users();
		u1.setEmail(dto.getEmail());
		u1.setName(dto.getName());
		u1.setPassword(encoder.encode(dto.getPassword()));
		u1.setPhone(dto.getPhone());
		u1.setRole(dto.getRole());
		
		repo.save(u1);
		
	
		return true;
	}



	@Override
	public String login(LoginRequestDto dto) {
	
		Optional<Users> op=repo.findByEmail(dto.getUsername());
//		Users user=repo.findByEmail(dto.getUsername()).orElse(null);
		
		if(op.isEmpty()) {
			return "User not exist";
		}
		
		if(!encoder.matches(dto.getPassword(),op.get().getPassword())) {
			return "Invalid Credentials";
		}
		
		return "Login Success";
		
		
	}
	
	 







	

	
}
