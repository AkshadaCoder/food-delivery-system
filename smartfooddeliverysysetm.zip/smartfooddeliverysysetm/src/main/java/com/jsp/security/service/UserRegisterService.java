package com.jsp.security.service;

import org.springframework.stereotype.Service;

import com.jsp.security.dto.LoginRequestDto;
import com.jsp.security.dto.RegisterRequestDto;

@Service
public interface UserRegisterService {

	public boolean register(RegisterRequestDto dto);
	public String login(LoginRequestDto dto);
}
