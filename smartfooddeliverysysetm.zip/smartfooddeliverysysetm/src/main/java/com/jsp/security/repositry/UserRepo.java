package com.jsp.security.repositry;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Jpa21Utils;
import org.springframework.stereotype.Repository;

import com.jsp.security.entity.Users;
import java.util.List;


@Repository
public interface UserRepo extends JpaRepository<Users, Integer> {

	Optional<Users> findByEmail(String email);
}
