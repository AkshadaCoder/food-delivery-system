
package com.jsp.security.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jsp.security.entity.Users;
import com.jsp.security.repositry.UserRepo;

@Controller
@RequestMapping("/profile")
public class ProfileController {

    @Autowired
    private UserRepo userRepo;

    @GetMapping
    public String showProfile(Principal principal, Model model) {

        Users user = userRepo.findByEmail(principal.getName())
                .orElseThrow(() ->
                    new IllegalStateException("Logged-in user not found"));

        model.addAttribute("user", user);

        return "profile";
    }
}
