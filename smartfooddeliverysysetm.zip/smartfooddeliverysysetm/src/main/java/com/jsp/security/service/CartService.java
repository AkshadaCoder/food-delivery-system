
package com.jsp.security.service;

import java.util.List;

import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jsp.security.entity.CartItem;
import com.jsp.security.entity.Users;
import com.jsp.security.repositry.CartItemRepo;
import com.jsp.security.repositry.UserRepo;

@Service
public class CartService {

    private final CartItemRepo cartItemRepo;
    private final UserRepo userRepo;

    public CartService(CartItemRepo cartItemRepo, UserRepo userRepo) {
        this.cartItemRepo = cartItemRepo;
        this.userRepo = userRepo;
    }

    private Users getCustomer(String email) {
        return userRepo.findByEmail(email)
                .orElseThrow(() ->
                    new UsernameNotFoundException("Customer not found"));
    }

    public List<CartItem> getCart(String email) {
        return cartItemRepo.findByCustomer_Email(email);
    }

    @Transactional
    public void addItem(String email, String foodName,
                        double price, int quantity) {

        if (foodName == null || foodName.isBlank()) {
            throw new IllegalArgumentException("Food name is required");
        }

        if (price <= 0 || !Double.isFinite(price)) {
            throw new IllegalArgumentException("Invalid food price");
        }

        if (quantity < 1 || quantity > 100) {
            throw new IllegalArgumentException("Quantity must be between 1 and 100");
        }

        Users customer = getCustomer(email);

        CartItem item = new CartItem(foodName.trim(), price, quantity, customer);

        cartItemRepo.save(item);
    }

    @Transactional
    public void updateQuantity(String email, int id, int quantity) {
        if (quantity < 1 || quantity > 100) {
            throw new IllegalArgumentException("Quantity must be between 1 and 100");
        }

        CartItem item = cartItemRepo.findByIdAndCustomer_Email(id, email)
                .orElseThrow(() ->
                    new IllegalArgumentException("Cart item not found"));

        item.setQuantity(quantity);
        cartItemRepo.save(item);
    }

    @Transactional
    public void removeItem(String email, int id) {
        CartItem item = cartItemRepo.findByIdAndCustomer_Email(id, email)
                .orElseThrow(() ->
                    new IllegalArgumentException("Cart item not found"));

        cartItemRepo.delete(item);
    }

    public double getTotal(String email) {
        return getCart(email).stream()
                .mapToDouble(CartItem::getSubtotal)
                .sum();
    }
}
