
package com.jsp.security.repositry;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.security.entity.CartItem;

public interface CartItemRepo extends JpaRepository<CartItem, Integer> {

    List<CartItem> findByCustomer_Email(String email);

    Optional<CartItem> findByIdAndCustomer_Email(int id, String email);
}
