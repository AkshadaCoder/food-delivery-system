package com.jsp.security.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/restrauant")
public class RestrauantController {

	
	@GetMapping("/dashboard")
	public String restaurant() {
		return "restaurant-dashboard";
	}
	
	
}
