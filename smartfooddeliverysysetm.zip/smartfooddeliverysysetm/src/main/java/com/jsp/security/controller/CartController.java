
package com.jsp.security.controller;

import java.security.Principal;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jsp.security.service.CartService;

@Controller
@RequestMapping("/customer/cart")
public class CartController {

    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @GetMapping
    public String viewCart(Principal principal, Model model) {
        String email = principal.getName();

        model.addAttribute("cartItems", cartService.getCart(email));
        model.addAttribute("total", cartService.getTotal(email));

        return "cart";
    }

    @PostMapping("/add")
    public String addToCart(pg
            Principal principal,
            @RequestParam String foodName,
            @RequestParam double price,
            @RequestParam(defaultValue = "1") int quantity,
            RedirectAttributes redirectAttributes) {

        try {
            cartService.addItem(
                    principal.getName(), foodName, price, quantity);

            redirectAttributes.addFlashAttribute(
                    "message", "Food added to your cart!");

        } catch (IllegalArgumentException ex) {
            redirectAttributes.addFlashAttribute(
                    "error", ex.getMessage());
        }

        return "redirect:/customer/cart";
    }

    @PostMapping("/update")
    public String updateQuantity(
            Principal principal,
            @RequestParam int id,
            @RequestParam int quantity,
            RedirectAttributes redirectAttributes) {

        try {
            cartService.updateQuantity(
                    principal.getName(), id, quantity);

            redirectAttributes.addFlashAttribute(
                    "message", "Cart quantity updated!");

        } catch (IllegalArgumentException ex) {
            redirectAttributes.addFlashAttribute(
                    "error", ex.getMessage());
        }

        return "redirect:/customer/cart";
    }

    @PostMapping("/remove")
    public String removeItem(
            Principal principal,
            @RequestParam int id,
            RedirectAttributes redirectAttributes) {

        try {
            cartService.removeItem(principal.getName(), id);

            redirectAttributes.addFlashAttribute(
                    "message", "Item removed from cart!");

        } catch (IllegalArgumentException ex) {
            redirectAttributes.addFlashAttribute(
                    "error", ex.getMessage());
        }

        return "redirect:/customer/cart";
    }
}
