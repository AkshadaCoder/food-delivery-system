package com.jsp.security.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jsp.security.dto.LoginRequestDto;
import com.jsp.security.dto.RegisterRequestDto;
import com.jsp.security.entity.Users;
import com.jsp.security.repositry.UserRepo;
import com.jsp.security.service.UserRegisterService;

import ch.qos.logback.core.model.Model;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/auth")
public class AuthController {

	@Autowired
	private UserRegisterService service;
	
	@Autowired
	private UserRepo repo;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@GetMapping("/register")
	public String register() {
		return "register";
	}
	
	@GetMapping("/foodlogin")
	public String login() {
		return "foodlogin";
	}
	

@PostMapping("/mylogin")
public String login(
        @Valid @ModelAttribute LoginRequestDto dto,
        org.springframework.ui.Model model,
        HttpServletRequest request,
        HttpServletResponse response) 
{

    String result = service.login(dto);

    if ("User not exist".equals(result)) {
        model.addAttribute(
            "errorMessage",
            "User does not exist. Please register first."
        );
        return "foodlogin";
    }

    if ("Invalid Credentials".equals(result)) {
        model.addAttribute(
            "errorMessage",
            "Invalid credentials. Please check your password."
        );
        return "foodlogin";
    }

    if (!"Login Success".equals(result)) {
        model.addAttribute(
            "errorMessage",
            "Login failed. Please try again."
        );
        return "foodlogin";
    }

    // Authenticate using Spring Security
    Authentication authentication;

    try {
        authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(
                dto.getUsername(),
                dto.getPassword()
            )
        );
    } catch (org.springframework.security.core.AuthenticationException e) {
        model.addAttribute(
            "errorMessage",
            "Authentication failed. Please check your credentials."
        );
        return "foodlogin";
    }

    // Establish the authenticated security context
    SecurityContext context =
        SecurityContextHolder.createEmptyContext();

    context.setAuthentication(authentication);
    SecurityContextHolder.setContext(context);

    // Save authentication in the HTTP session
    request.getSession(true);

    new HttpSessionSecurityContextRepository()
        .saveContext(context, request, response);

    // Find user and redirect according to role
    Optional<Users> optionalUser =
        repo.findByEmail(dto.getUsername());

    if (optionalUser.isEmpty()) {
        SecurityContextHolder.clearContext();
        request.getSession().invalidate();

        model.addAttribute(
            "errorMessage",
            "User account not found."
        );
        return "foodlogin";
    }

    Users user = optionalUser.get();

    if ("USER".equals(user.getRole())) {
        return "redirect:/customer/dashboard";
    }

    if ("RESTAURANT".equals(user.getRole())) {
        return "redirect:/restrauant/dashboard";
    }

    if ("DELIVERY_AGENT".equals(user.getRole())) {
        return "redirect:/delivery/dashboard";
    }

    // Invalid role
    SecurityContextHolder.clearContext();
    request.getSession().invalidate();

    model.addAttribute(
        "errorMessage",
        "Your account has an invalid role."
    );

    return "foodlogin";
}


	
	@PostMapping("/register")
	public String register(
	        @Valid @ModelAttribute("dto") RegisterRequestDto dto,
	        RedirectAttributes redirectAttributes) {

	    if (!service.register(dto)) {
	        redirectAttributes.addFlashAttribute(
	            "errorMessage",
	            "User already exists with this email!"
	        );

	        return "redirect:/auth/register";
	    }

	    redirectAttributes.addFlashAttribute(
	        "successMessage",
	        "Registration successful!"
	    );

	    return "redirect:/auth/foodlogin";
	}
	
	
}
