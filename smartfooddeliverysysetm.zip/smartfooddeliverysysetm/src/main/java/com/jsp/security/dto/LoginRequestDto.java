package com.jsp.security.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;

public class LoginRequestDto {

	
	@NotNull
	@Email
	private String username;
	@NotNull
	private String password;
	public LoginRequestDto(@NotNull @Email String username, @NotNull String password) {
		super();
		this.username = username;
		this.password = password;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
