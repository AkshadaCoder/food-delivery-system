package com.jsp.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartfooddeliverysysetmApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartfooddeliverysysetmApplication.class, args);
	}

}
