
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FoodSwift | Biryani</title>
    <link rel="stylesheet"
          href="${pageContext.request.contextPath}/css/biryani.css">
</head>
<body>

<header class="navbar">
    <a class="brand"
       href="${pageContext.request.contextPath}/customer/dashboard">
        Food<span>Swift</span>
        <small>From Kitchen to Doorstep</small>
    </a>
    <nav>
        <a href="${pageContext.request.contextPath}/customer/dashboard">Home</a>
        <a href="${pageContext.request.contextPath}/customer/cart">🛒 Cart</a>
        <a href="${pageContext.request.contextPath}/customer/orders">My Orders</a>
    </nav>
</header>

<main class="container">
    <section class="category-banner biryani-banner">
        <p class="eyebrow">MADE WITH LOVE</p>
        <h1>Biryani Specials</h1>
        <p>Fragrant rice, rich spices and delicious flavours.</p>
    </section>

    <h2>Explore Biryani</h2>
    <p class="subtitle">Choose your favourite biryani.</p>

    <div class="food-grid">
        <article class="food-card">
            <div class="food-emoji">🍚</div>
            <div class="food-details">
                <h3>Veg Biryani</h3>
                <p>Aromatic basmati rice with fresh vegetables and spices.</p>
                <div class="food-bottom">
                    <strong>₹150</strong>
					<form action="${pageContext.request.contextPath}/customer/cart/add"
					      method="post">

					    <input type="hidden" name="${_csrf.parameterName}"
					           value="${_csrf.token}">

					    <input type="hidden" name="foodId" value="1">
					    <input type="hidden" name="foodName" value="Veg Biryani">
					    <input type="hidden" name="price" value="150">

					    <button type="submit" class="order-btn">
					        Add to Cart
					    </button>
					</form>
                </div>
            </div>
        </article>

        <article class="food-card">
            <div class="food-emoji">🍗</div>
            <div class="food-details">
                <h3>Chicken Biryani</h3>
                <p>Spiced basmati rice with tender chicken.</p>
                <div class="food-bottom">
                    <strong>₹220</strong>
					<form action="${pageContext.request.contextPath}/customer/cart/add"
					      method="post">

					    <input type="hidden" name="${_csrf.parameterName}"
					           value="${_csrf.token}">

					    <input type="hidden" name="foodId" value="1">
					    <input type="hidden" name="foodName" value="Chicken Biryani">
					    <input type="hidden" name="price" value="150">

					    <button type="submit" class="order-btn">
					        Add to Cart
					    </button>
					</form>
                </div>
            </div>
        </article>

        <article class="food-card">
            <div class="food-emoji">🍛</div>
            <div class="food-details">
                <h3>Paneer Biryani</h3>
                <p>Flavourful rice cooked with paneer and Indian spices.</p>
                <div class="food-bottom">
                    <strong>₹180</strong>
					<form action="${pageContext.request.contextPath}/customer/cart/add"
					      method="post">

					    <input type="hidden" name="${_csrf.parameterName}"
					           value="${_csrf.token}">

					    <input type="hidden" name="foodId" value="1">
					    <input type="hidden" name="foodName" value="Paneer Biryani">
					    <input type="hidden" name="price" value="180">

					    <button type="submit" class="order-btn">
					        Add to Cart
					    </button>
					</form>
                </div>
            </div>
        </article>

        <article class="food-card">
            <div class="food-emoji">🍲</div>
            <div class="food-details">
                <h3>Hyderabadi Biryani</h3>
                <p>A traditional dum-style biryani with bold spices.</p>
                <div class="food-bottom">
                    <strong>₹250</strong>
					<form action="${pageContext.request.contextPath}/customer/cart/add"
					      method="post">

					    <input type="hidden" name="${_csrf.parameterName}"
					           value="${_csrf.token}">

					    <input type="hidden" name="foodId" value="1">
					    <input type="hidden" name="foodName" value="Hyderabadi Biryani">
					    <input type="hidden" name="price" value="250">

					    <button type="submit" class="order-btn">
					        Add to Cart
					    </button>
					</form>
                </div>
            </div>
        </article>
    </div>

    <a class="back-link"
       href="${pageContext.request.contextPath}/customer/dashboard">
        ← Back to Dashboard
    </a>
</main>

</body>
</html>
