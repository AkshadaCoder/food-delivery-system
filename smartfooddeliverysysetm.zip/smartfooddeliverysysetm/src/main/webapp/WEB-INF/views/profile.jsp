<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile | FoodSwift</title>

    <link rel="stylesheet"
          href="${pageContext.request.contextPath}/css/profile.css">
</head>
<body>

<header class="navbar">
    <a href="${pageContext.request.contextPath}/home" class="brand">
        FoodSwift
    </a>

    <nav>
        <a href="${pageContext.request.contextPath}/home">Home</a>
        <a href="${pageContext.request.contextPath}/profile"
           class="active">My Profile</a>

        <form action="${pageContext.request.contextPath}/logout"
              method="post" class="logout-form">
            <c:if test="${_csrf != null}">
                <input type="hidden" name="${_csrf.parameterName}"
                       value="${_csrf.token}">
            </c:if>
            <button type="submit" class="logout-btn">Logout</button>
        </form>
    </nav>
</header>

<main class="profile-container">

    <section class="profile-heading">
        <h1>My Profile</h1>
        <p>Manage your FoodSwift account information.</p>
    </section>

    <c:if test="${not empty successMessage}">
        <div class="success-message">
            <c:out value="${successMessage}"/>
        </div>
    </c:if>

    <c:if test="${not empty errorMessage}">
        <div class="error-message">
            <c:out value="${errorMessage}"/>
        </div>
    </c:if>

    <section class="profile-card">

        <div class="profile-header">
            <div class="avatar">
                <c:choose>
                    <c:when test="${not empty user.name}">
                        <c:out value="${user.name.substring(0,1).toUpperCase()}"/>
                    </c:when>
                    <c:otherwise>U</c:otherwise>
                </c:choose>
            </div>

            <div>
                <h2><c:out value="${user.name}"/></h2>
                <p><c:out value="${user.role}"/></p>
                <span class="account-status">FoodSwift Member</span>
            </div>
        </div>

        <h3 class="section-title">Personal Information</h3>

        <form action="${pageContext.request.contextPath}/profile/update"
              method="post" id="profileForm">

            <c:if test="${_csrf != null}">
                <input type="hidden" name="${_csrf.parameterName}"
                       value="${_csrf.token}">
            </c:if>

            <div class="form-grid">

                <div class="form-group">
                    <label for="id">User ID</label>
                    <input type="text" id="id"
                           value="<c:out value='${user.id}'/>"
                           readonly>
                </div>

                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" id="name" name="name"
                           value="<c:out value='${user.name}'/>"
                           maxlength="100" required disabled>
                </div>

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email"
                           value="<c:out value='${user.email}'/>"
                           readonly>
                </div>

                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone"
                           value="<c:out value='${user.phone}'/>"
                           pattern="[0-9]{10}"
                           maxlength="10" minlength="10"
                           required disabled>
                </div>

                <div class="form-group full-width">
                    <label for="role">Account Role</label>
                    <input type="text" id="role"
                           value="<c:out value='${user.role}'/>"
                           readonly>
                </div>

            </div>

            <div class="form-actions">
                <button type="button" id="editBtn" class="btn-primary">
                    Edit Profile
                </button>

                <button type="submit" id="saveBtn"
                        class="btn-primary" hidden>
                    Save Changes
                </button>

                <button type="button" id="cancelBtn"
                        class="btn-secondary" hidden>
                    Cancel
                </button>
            </div>

        </form>
    </section>
</main>

<script>
    const form = document.getElementById("profileForm");
    const nameField = document.getElementById("name");
    const phoneField = document.getElementById("phone");

    const editableFields = [nameField, phoneField];

    const editBtn = document.getElementById("editBtn");
    const saveBtn = document.getElementById("saveBtn");
    const cancelBtn = document.getElementById("cancelBtn");

    let originalValues = [];

    editBtn.addEventListener("click", function () {
        originalValues = editableFields.map(field => field.value);

        editableFields.forEach(field => field.disabled = false);

        editBtn.hidden = true;
        saveBtn.hidden = false;
        cancelBtn.hidden = false;

        nameField.focus();
    });

    cancelBtn.addEventListener("click", function () {
        editableFields.forEach((field, index) => {
            field.value = originalValues[index];
            field.disabled = true;
        });

        editBtn.hidden = false;
        saveBtn.hidden = true;
        cancelBtn.hidden = true;
    });
</script>

</body>
</html>
