
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>FoodSwift | Delivery Dashboard</title>

<link rel="stylesheet"
      href="${pageContext.request.contextPath}/css/delivery-dashboard.css">
</head>

<body>

<div class="dashboard">

    <!-- Sidebar -->
    <aside class="sidebar">

        <h2 class="logo">Food<span>Swift</span></h2>
        <p class="panel-label">DELIVERY PARTNER</p>

        <nav>
            <a href="${pageContext.request.contextPath}/delivery/dashboard"
               class="active">🏠 Dashboard</a>

            <a href="${pageContext.request.contextPath}/delivery/tasks">
                📦 My Deliveries
            </a>

            <a href="${pageContext.request.contextPath}/delivery/history">
                🕒 Delivery History
            </a>

            <a href="${pageContext.request.contextPath}/delivery/earnings">
                💰 My Earnings
            </a>

            <a href="${pageContext.request.contextPath}/profile">
                👤 My Profile
            </a>
        </nav>

        <div class="sidebar-bottom">
            <p>FoodSwift Partner</p>

            <a href="${pageContext.request.contextPath}/logout"
               class="logout">↪ Logout</a>
        </div>

    </aside>


    <!-- Main Content -->
    <main class="main-content">

        <!-- Header -->
        <header class="topbar">

            <div>
                <h1>Delivery Dashboard</h1>
                <p>Manage your deliveries and track your earnings.</p>
            </div>

            <div class="agent-profile">
                <div class="avatar">D</div>
                <div>
                    <strong>
                        <c:out value="${agentName}"
                               default="Delivery Partner"/>
                    </strong>
                    <p>Delivery Agent</p>
                </div>
            </div>

        </header>


        <!-- Welcome -->
        <section class="welcome">

            <div>
                <h2>Hello,
                    <c:out value="${agentName}"
                           default="Delivery Partner"/>! 👋
                </h2>

                <p>Ready to deliver happiness today?</p>

                <p class="availability">
                    <span class="online-dot"></span>
                    Check your assigned deliveries below
                </p>
            </div>

            <a href="${pageContext.request.contextPath}/delivery/tasks"
               class="primary-btn">
                View Deliveries →
            </a>

        </section>


        <!-- Statistics -->
        <section class="stats">

            <div class="stat-card">
                <div class="stat-icon green">📦</div>
                <p>Today's Deliveries</p>
                <h2>
                    <c:out value="${todayDeliveries}" default="0"/>
                </h2>
                <span>Orders delivered today</span>
            </div>

            <div class="stat-card">
                <div class="stat-icon orange">⏳</div>
                <p>Pending Deliveries</p>
                <h2>
                    <c:out value="${pendingDeliveries}" default="0"/>
                </h2>
                <span>Tasks awaiting completion</span>
            </div>

            <div class="stat-card">
                <div class="stat-icon blue">💰</div>
                <p>Today's Earnings</p>
                <h2>₹<c:out value="${todayEarnings}" default="0.00"/></h2>
                <span>Earnings for today</span>
            </div>

            <div class="stat-card">
                <div class="stat-icon purple">🏆</div>
                <p>Total Deliveries</p>
                <h2>
                    <c:out value="${totalDeliveries}" default="0"/>
                </h2>
                <span>All-time completed deliveries</span>
            </div>

        </section>


        <!-- Assigned Deliveries -->
        <section class="panel">

            <div class="panel-header">
                <div>
                    <h2>My Assigned Deliveries</h2>
                    <p>View orders assigned to you and their current status.</p>
                </div>

                <a href="${pageContext.request.contextPath}/delivery/tasks"
                   class="view-all">
                    View All →
                </a>
            </div>


            <div class="table-wrapper">

                <table>
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Delivery Address</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>

                        <c:choose>

                            <c:when test="${not empty assignedDeliveries}">

                                <c:forEach var="delivery"
                                           items="${assignedDeliveries}">

                                    <tr>
                                        <td>
                                            #<c:out value="${delivery.orderId}"/>
                                        </td>

                                        <td>
                                            <c:out value="${delivery.customerName}"/>
                                        </td>

                                        <td class="address">
                                            <c:out value="${delivery.deliveryAddress}"/>
                                        </td>

                                        <td>
                                            ₹<c:out value="${delivery.amount}"/>
                                        </td>

                                        <td>
                                            <span class="status">
                                                <c:out value="${delivery.status}"/>
                                            </span>
                                        </td>

                                        <td>
                                            <a class="action-btn"
                                               href="${pageContext.request.contextPath}/delivery/tasks/${delivery.id}">
                                                View Details
                                            </a>
                                        </td>
                                    </tr>

                                </c:forEach>

                            </c:when>

                            <c:otherwise>

                                <tr>
                                    <td colspan="6" class="empty">
                                        <div class="empty-icon">🛵</div>
                                        <strong>No deliveries assigned yet</strong>
                                        <p>Your assigned orders will appear here.</p>
                                    </td>
                                </tr>

                            </c:otherwise>

                        </c:choose>

                    </tbody>
                </table>

            </div>

        </section>


        <!-- Delivery Workflow -->
        <section class="panel workflow-panel">

            <h2>Delivery Process</h2>
            <p class="section-description">
                Follow these steps to complete a delivery.
            </p>

            <div class="workflow">

                <div class="workflow-step">
                    <span>1</span>
                    <h3>Accept Order</h3>
                    <p>Review and accept your assigned delivery.</p>
                </div>

                <div class="workflow-step">
                    <span>2</span>
                    <h3>Pick Up Food</h3>
                    <p>Collect the prepared order from the restaurant.</p>
                </div>

                <div class="workflow-step">
                    <span>3</span>
                    <h3>Deliver Order</h3>
                    <p>Travel to the customer’s delivery address.</p>
                </div>

                <div class="workflow-step">
                    <span>4</span>
                    <h3>Complete Delivery</h3>
                    <p>Confirm successful delivery to the customer.</p>
                </div>

            </div>

        </section>


        <!-- Quick Actions -->
        <section class="quick-section">

            <h2>Quick Actions</h2>

            <div class="quick-actions">

                <a href="${pageContext.request.contextPath}/delivery/tasks"
                   class="quick-card">
                    <span>🛵</span>
                    <div>
                        <h3>My Deliveries</h3>
                        <p>View your assigned orders.</p>
                    </div>
                    <b>→</b>
                </a>

                <a href="${pageContext.request.contextPath}/delivery/earnings"
                   class="quick-card">
                    <span>💵</span>
                    <div>
                        <h3>View Earnings</h3>
                        <p>Check your delivery income.</p>
                    </div>
                    <b>→</b>
                </a>

                <a href="${pageContext.request.contextPath}/delivery/profile"
                   class="quick-card">
                    <span>⚙️</span>
                    <div>
                        <h3>Update Profile</h3>
                        <p>Manage your account details.</p>
                    </div>
                    <b>→</b>
                </a>

            </div>

        </section>


        <footer>
            © 2026 FoodSwift. From Kitchen to Doorstep.
        </footer>

    </main>

</div>

</body>
</html>
