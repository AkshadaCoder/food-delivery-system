
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>FoodSwift | Restaurant Dashboard</title>

<link rel="stylesheet"
      href="${pageContext.request.contextPath}/css/restaurant-dashboard.css">
</head>

<body>

<div class="dashboard">

    <!-- Sidebar -->
    <aside class="sidebar">
        <h2 class="logo">Food<span>Swift</span></h2>
        <p class="sidebar-label">RESTAURANT PANEL</p>

        <nav>
            <a href="${pageContext.request.contextPath}/restaurant/dashboard"
               class="active">🏠 Dashboard</a>

            <a href="${pageContext.request.contextPath}/restaurant/orders">
                📦 Orders
            </a>

            <a href="${pageContext.request.contextPath}/restaurant/menu">
                🍽️ Manage Menu
            </a>

            <a href="${pageContext.request.contextPath}/restaurant/sales">
                📊 Sales & Reports
            </a>

            <a href="${pageContext.request.contextPath}/profile">
                ⚙️ Restaurant Profile
            </a>
        </nav>

        <div class="sidebar-bottom">
            <p>FoodSwift Partner</p>
            <a href="${pageContext.request.contextPath}/logout"
               class="logout">↪ Logout</a>
        </div>
    </aside>


    <!-- Main Content -->
    <main class="main-content">

        <header class="topbar">
            <div>
                <h1>Restaurant Dashboard</h1>
                <p>Manage your restaurant and orders in one place.</p>
            </div>

            <div class="profile">
                <div class="avatar">R</div>
                <div>
                    <strong>
                        <c:out value="${restaurantName}"
                               default="Restaurant Owner"/>
                    </strong>
                    <p>Restaurant Partner</p>
                </div>
            </div>
        </header>


        <!-- Welcome Section -->
        <section class="welcome">
            <div>
                <h2>Welcome back,
                    <c:out value="${restaurantName}"
                           default="Restaurant Owner"/>!
                </h2>
                <p>Here is what is happening with your restaurant today.</p>
            </div>

            <a href="${pageContext.request.contextPath}/restaurant/menu"
               class="primary-btn">+ Manage Menu</a>
        </section>


        <!-- Statistics -->
        <section class="stats">

            <div class="stat-card">
                <div class="stat-icon orange">📦</div>
                <p>Total Orders Today</p>
                <h2><c:out value="${totalOrders}" default="0"/></h2>
                <span>Orders received today</span>
            </div>

            <div class="stat-card">
                <div class="stat-icon green">💰</div>
                <p>Today's Revenue</p>
                <h2>₹<c:out value="${todayRevenue}" default="0.00"/></h2>
                <span>Revenue from orders</span>
            </div>

            <div class="stat-card">
                <div class="stat-icon blue">⏳</div>
                <p>Pending Orders</p>
                <h2><c:out value="${pendingOrders}" default="0"/></h2>
                <span>Orders awaiting action</span>
            </div>

            <div class="stat-card">
                <div class="stat-icon purple">🍽️</div>
                <p>Menu Items</p>
                <h2><c:out value="${totalMenuItems}" default="0"/></h2>
                <span>Items in your menu</span>
            </div>

        </section>


        <!-- Recent Orders -->
        <section class="panel">

            <div class="panel-header">
                <div>
                    <h2>Recent Orders</h2>
                    <p>Review and manage customer orders.</p>
                </div>

                <a href="${pageContext.request.contextPath}/restaurant/orders"
                   class="view-all">View All →</a>
            </div>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Order Date</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <c:choose>
                            <c:when test="${not empty recentOrders}">
                                <c:forEach var="order" items="${recentOrders}">
                                    <tr>
                                        <td>
                                            #<c:out value="${order.id}"/>
                                        </td>
                                        <td>
                                            <c:out value="${order.customerName}"/>
                                        </td>
                                        <td>
                                            <c:out value="${order.orderDate}"/>
                                        </td>
                                        <td>
                                            ₹<c:out value="${order.totalAmount}"/>
                                        </td>
                                        <td>
                                            <span class="status">
                                                <c:out value="${order.status}"/>
                                            </span>
                                        </td>
                                        <td>
                                            <a class="action-btn"
                                               href="${pageContext.request.contextPath}/restaurant/orders/${order.id}">
                                                View
                                            </a>
                                        </td>
                                    </tr>
                                </c:forEach>
                            </c:when>

                            <c:otherwise>
                                <tr>
                                    <td colspan="6" class="empty">
                                        No orders available yet.
                                    </td>
                                </tr>
                            </c:otherwise>
                        </c:choose>
                    </tbody>
                </table>
            </div>
        </section>


        <!-- Quick Actions -->
        <section class="quick-section">
            <h2>Quick Actions</h2>

            <div class="quick-actions">

                <a href="${pageContext.request.contextPath}/restaurant/menu"
                   class="quick-card">
                    <span>🍔</span>
                    <div>
                        <h3>Manage Menu</h3>
                        <p>Add, edit or remove food items.</p>
                    </div>
                    <b>→</b>
                </a>

                <a href="${pageContext.request.contextPath}/restaurant/orders"
                   class="quick-card">
                    <span>🛵</span>
                    <div>
                        <h3>Manage Orders</h3>
                        <p>Accept and prepare customer orders.</p>
                    </div>
                    <b>→</b>
                </a>

                <a href="${pageContext.request.contextPath}/restaurant/profile"
                   class="quick-card">
                    <span>🏪</span>
                    <div>
                        <h3>Restaurant Profile</h3>
                        <p>Update restaurant details.</p>
                    </div>
                    <b>→</b>
                </a>

            </div>
        </section>

        <footer>
            © 2026 FoodSwift. From Kitchen to Doorstep.
        </footer>

    </main>
</div>

</body>
</html>