
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FoodSwift | Pizza</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/pizza.css">
</head>
<body>
<header class="navbar">
    <a class="brand" href="${pageContext.request.contextPath}/customer/dashboard">
        Food<span>Swift</span><small>From Kitchen to Doorstep</small>
    </a>
    <nav>
        <a href="${pageContext.request.contextPath}/customer/dashboard">Home</a>
        <a href="${pageContext.request.contextPath}/customer/cart">🛒 Cart</a>
    </nav>
</header>

<main class="container">
    <section class="category-banner pizza-banner">
        <p class="eyebrow">CHEESY • FRESH • DELICIOUS</p>
        <h1>Pizza Paradise</h1>
        <p>Discover your next favourite slice.</p>
    </section>

    <h2>Our Pizza Menu</h2>
    <div class="food-grid">
        <article class="food-card">
            <div class="food-emoji">🍕</div>
            <div class="food-details">
                <h3>Margherita Pizza</h3>
                <p>Classic pizza with cheese, tomato and herbs.</p>
                <div class="food-bottom"><strong>₹149</strong>
                    <a class="order-btn" href="${pageContext.request.contextPath}/customer/cart">Order Now</a>
                </div>
            </div>
        </article>
        <article class="food-card">
            <div class="food-emoji">🍕</div>
            <div class="food-details">
                <h3>Farmhouse Pizza</h3>
                <p>Loaded with capsicum, onion, tomato and cheese.</p>
                <div class="food-bottom"><strong>₹249</strong>
                    <a class="order-btn" href="${pageContext.request.contextPath}/customer/cart">Order Now</a>
                </div>
            </div>
        </article>
        <article class="food-card">
            <div class="food-emoji">🧀</div>
            <div class="food-details">
                <h3>Cheese Burst Pizza</h3>
                <p>Soft crust filled with rich, melted cheese.</p>
                <div class="food-bottom"><strong>₹229</strong>
                    <a class="order-btn" href="${pageContext.request.contextPath}/customer/cart">Order Now</a>
                </div>
            </div>
        </article>
        <article class="food-card">
            <div class="food-emoji">🍕</div>
            <div class="food-details">
                <h3>Paneer Tikka Pizza</h3>
                <p>Spicy paneer tikka with onions and cheese.</p>
                <div class="food-bottom"><strong>₹269</strong>
                    <a class="order-btn" href="${pageContext.request.contextPath}/customer/cart">Order Now</a>
                </div>
            </div>
        </article>
    </div>
    <a class="back-link" href="${pageContext.request.contextPath}/customer/dashboard">← Back to Dashboard</a>
</main>
</body>
</html>
