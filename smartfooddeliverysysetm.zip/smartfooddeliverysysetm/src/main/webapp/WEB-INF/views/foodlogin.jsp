
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login | FoodSwift</title>

    <link rel="stylesheet"
          href="${pageContext.request.contextPath}/css/mylogin.css">
</head>

<body>

    <main class="login-container">

        <section class="login-card">

            <!-- FoodSwift Brand -->
            <a href="${pageContext.request.contextPath}/home"
               class="brand">
                Food<span>Swift</span>
            </a>

            <h1>Welcome Back!</h1>

            <p class="subtitle">
                Login to continue your food journey.
            </p>

            <!-- Error Message -->
            <c:if test="${not empty errorMessage}">
                <div class="error-message" role="alert">
                    <c:out value="${errorMessage}" />
                </div>
            </c:if>

            <!-- Success Message -->
            <c:if test="${not empty successMessage}">
                <div class="success-message" role="status">
                    <c:out value="${successMessage}" />
                </div>
            </c:if>

            <!-- Login Form -->
            <form action="${pageContext.request.contextPath}/auth/mylogin"
                  method="post">

                <!-- CSRF Token -->
                <c:if test="${_csrf ne null}">
                    <input type="hidden"
                           name="${_csrf.parameterName}"
                           value="${_csrf.token}">
                </c:if>

                <!-- Email -->
                <div class="form-group">
                    <label for="email">Email Address</label>

                    <input
                        type="email"
                        id="email"
                        name="username"
                        placeholder="Enter your registered email"
                        autocomplete="email"
                        required>
                </div>

                <!-- Password -->
                <div class="form-group">
                    <label for="password">Password</label>

                    <div class="password-wrapper">
                        <input
                            type="password"
                            id="password"
                            name="password"
                            placeholder="Enter your password"
                            autocomplete="current-password"
                            required>

                        <button
                            type="button"
                            class="toggle-password"
                            id="togglePassword"
                            aria-controls="password"
                            aria-pressed="false">
                            Show
                        </button>
                    </div>
                </div>

                <!-- Login Button -->
                <button type="submit" class="login-button">
                    Login
                    <span aria-hidden="true">→</span>
                </button>

            </form>

            <!-- Register Link -->
            <p class="register-text">
                Don't have an account?
                <a href="${pageContext.request.contextPath}/auth/register">
                    Sign Up
                </a>
            </p>

            <!-- Home Link -->
            <a href="${pageContext.request.contextPath}/home"
               class="back-home">
                ← Back to Home
            </a>

        </section>

        <footer class="page-footer">
            FoodSwift — From Kitchen to Doorstep.
        </footer>

    </main>

    <!-- Show / Hide Password -->
    <script>
        const passwordInput = document.getElementById("password");
        const toggleButton = document.getElementById("togglePassword");

        toggleButton.addEventListener("click", function () {
            const isPassword = passwordInput.type === "password";

            passwordInput.type = isPassword ? "text" : "password";
            toggleButton.textContent = isPassword ? "Hide" : "Show";
            toggleButton.setAttribute("aria-pressed", String(isPassword));
        });
    </script>

</body>
</html>
