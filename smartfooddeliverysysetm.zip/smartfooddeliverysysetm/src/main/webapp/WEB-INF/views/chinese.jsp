
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FoodSwift | Chinese</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/chinese.css">
</head>
<body>
<header class="navbar">
    <a class="brand" href="${pageContext.request.contextPath}/customer/dashboard">
        Food<span>Swift</span><small>From Kitchen to Doorstep</small>
    </a>
    <nav>
        <a href="${pageContext.request.contextPath}/customer/dashboard">Home</a>
        <a href="${pageContext.request.contextPath}/customer/cart">🛒 Cart</a>
    </nav>
</header>

<main class="container">
    <section class="category-banner chinese-banner">
        <p class="eyebrow">HOT • SPICY • DELICIOUS</p>
        <h1>Chinese Favourites</h1>
        <p>Enjoy flavourful noodles, rice and starters.</p>
    </section>

    <h2>Chinese Menu</h2>
    <div class="food-grid">
        <article class="food-card">
            <div class="food-emoji">🍜</div>
            <div class="food-details">
                <h3>Veg Hakka Noodles</h3>
                <p>Stir-fried noodles with fresh vegetables.</p>
                <div class="food-bottom"><strong>₹130</strong>
					<form action="${pageContext.request.contextPath}/customer/cart/add"
					      method="post">

					    <input type="hidden" name="${_csrf.parameterName}"
					           value="${_csrf.token}">

					    <input type="hidden" name="foodId" value="1">
					    <input type="hidden" name="foodName" value="Stir-fried noodles with fresh vegetables">
					    <input type="hidden" name="price" value="130">

					    <button type="submit" class="order-btn">
					        Add to Cart
					    </button>
					</form>

                </div>
            </div>
        </article>
        <article class="food-card">
            <div class="food-emoji">🍚</div>
            <div class="food-details">
                <h3>Veg Fried Rice</h3>
                <p>Fried rice tossed with vegetables and sauces.</p>
                <div class="food-bottom"><strong>₹120</strong>
					<form action="${pageContext.request.contextPath}/customer/cart/add"
					      method="post">

					    <input type="hidden" name="${_csrf.parameterName}"
					           value="${_csrf.token}">

					    <input type="hidden" name="foodId" value="1">
					    <input type="hidden" name="foodName" value="Veg Fried Rice">
					    <input type="hidden" name="price" value="120">

					    <button type="submit" class="order-btn">
					        Add to Cart
					    </button>
					</form>
                </div>
            </div>
        </article>
        <article class="food-card">
            <div class="food-emoji">🥡</div>
            <div class="food-details">
                <h3>Veg Manchurian</h3>
                <p>Vegetable dumplings in a tangy sauce.</p>
                <div class="food-bottom"><strong>₹140</strong>
					<form action="${pageContext.request.contextPath}/customer/cart/add"
					      method="post">

					    <input type="hidden" name="${_csrf.parameterName}"
					           value="${_csrf.token}">

					    <input type="hidden" name="foodId" value="1">
					    <input type="hidden" name="foodName" value="Veg Manchurian">
					    <input type="hidden" name="price" value="140">

					    <button type="submit" class="order-btn">
					        Add to Cart
					    </button>
					</form>
                </div>
            </div>
        </article>
        <article class="food-card">
            <div class="food-emoji">🌶️</div>
            <div class="food-details">
                <h3>Schezwan Noodles</h3>
                <p>Spicy noodles tossed in Schezwan sauce.</p>
                <div class="food-bottom"><strong>₹150</strong>
					<form action="${pageContext.request.contextPath}/customer/cart/add"
					      method="post">

					    <input type="hidden" name="${_csrf.parameterName}"
					           value="${_csrf.token}">

					    <input type="hidden" name="foodId" value="1">
					    <input type="hidden" name="foodName" value="Schezwan Noodles">
					    <input type="hidden" name="price" value="150">

					    <button type="submit" class="order-btn">
					        Add to Cart
					    </button>
					</form>
                </div>
            </div>
        </article>
    </div>
    <a class="back-link" href="${pageContext.request.contextPath}/customer/dashboard">← Back to Dashboard</a>
</main>
</body>
</html>
