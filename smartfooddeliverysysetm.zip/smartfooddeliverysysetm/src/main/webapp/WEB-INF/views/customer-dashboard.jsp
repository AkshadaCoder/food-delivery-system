
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>FoodSwift | Customer Dashboard</title>

    <link rel="stylesheet"
          href="${pageContext.request.contextPath}/css/customer-dashboard.css">
</head>
<body>

<!-- Navigation -->
<header class="navbar">
    <a href="${pageContext.request.contextPath}/customer/dashboard"
       class="brand">
        Food<span>Swift</span>
        <small>From Kitchen to Doorstep</small>
    </a>

    <form class="search-form"
          action="${pageContext.request.contextPath}/customer/restaurants"
          method="get">
        <input type="search" name="keyword"
               placeholder="Search restaurants or dishes...">
        <button type="submit">Search</button>
    </form>

    <nav class="nav-links">
        <a href="${pageContext.request.contextPath}/customer/orders">
            My Orders
        </a>
        <a href="${pageContext.request.contextPath}/customer/cart">
            🛒 Cart
        </a>
        <a href="${pageContext.request.contextPath}/profile">
            My Profile
        </a>
        <form action="${pageContext.request.contextPath}/logout"
              method="post" class="logout-form">
            <button type="submit" class="logout-btn">Logout</button>
        </form>
    </nav>
</header>

<main class="container">

    <!-- Welcome section -->
    <section class="welcome-section">
        <div>
            <p class="eyebrow">YOUR FOOD, YOUR WAY</p>
            <h1>Good food, happy mood!</h1>
            <p class="subtitle">
                Discover delicious meals and get them delivered to your door.
            </p>
            <a href="#restaurants" class="primary-btn">
                Explore Restaurants
            </a>
        </div>

        <div class="hero-art">
            <span class="hero-emoji">🍱</span>
            <div>
                <strong>Fresh. Fast. Delicious.</strong>
                <p>Your next favourite meal is waiting.</p>
            </div>
        </div>
    </section>

    <!-- Food categories -->
    <section class="section">
        <div class="section-heading">
            <div>
                <h2>What are you craving?</h2>
                <p>Choose your favourite category</p>
            </div>
        </div>

        <div class="category-grid">
            <a class="category-card" href="${pageContext.request.contextPath}/customer/restaurants?category=biryani">
                <span>🍛</span>
                <strong>Biryani</strong>
            </a>

            <a class="category-card" href="${pageContext.request.contextPath}/customer/restaurants?category=pizza">
                <span>🍕</span>
                <strong>Pizza</strong>
            </a>

            <a class="category-card" href="${pageContext.request.contextPath}/customer/restaurants?category=burgers">
                <span>🍔</span>
                <strong>Burgers</strong>
            </a>

            <a class="category-card" href="${pageContext.request.contextPath}/customer/restaurants?category=south-indian">
                <span>🥞</span>
                <strong>South Indian</strong>
            </a>

            <a class="category-card" href="${pageContext.request.contextPath}/customer/restaurants?category=chinese">
                <span>🍜</span>
                <strong>Chinese</strong>
            </a>

            <a class="category-card" href="${pageContext.request.contextPath}/customer/restaurants?category=desserts">
                <span>🍰</span>
                <strong>Desserts</strong>
            </a>
        </div>
    </section>

    <!-- Restaurant listings -->
    <section class="section" id="restaurants">
        <div class="section-heading">
            <div>
                <h2>Popular restaurants</h2>
                <p>Discover something delicious today</p>
            </div>
            <a class="text-link"
               href="${pageContext.request.contextPath}/customer/restaurants">
                View all →
            </a>
        </div>

        <div class="restaurant-grid">

            <article class="restaurant-card">
                <div class="food-image biryani">
                    <span>🍛</span>
                    <span class="food-badge">POPULAR</span>
                </div>
                <div class="restaurant-info">
                    <h3>Spice Garden</h3>
                    <p>Indian • Biryani • Thali</p>
                    <div class="restaurant-meta">
                        <span>⭐ 4.7</span>
                        <span>25–35 min</span>
                    </div>
                    <a class="order-link"
                       href="${pageContext.request.contextPath}/customer/restaurants">
                        View Menu →
                    </a>
                </div>
            </article>

            <article class="restaurant-card">
                <div class="food-image pizza">
                    <span>🍕</span>
                    <span class="food-badge">BEST SELLER</span>
                </div>
                <div class="restaurant-info">
                    <h3>Pizza Corner</h3>
                    <p>Pizza • Italian • Pasta</p>
                    <div class="restaurant-meta">
                        <span>⭐ 4.6</span>
                        <span>30–40 min</span>
                    </div>
                    <a class="order-link"
                       href="${pageContext.request.contextPath}/customer/restaurants">
                        View Menu →
                    </a>
                </div>
            </article>

            <article class="restaurant-card">
                <div class="food-image burger">
                    <span>🍔</span>
                </div>
                <div class="restaurant-info">
                    <h3>Burger Hub</h3>
                    <p>Burgers • Fries • Wraps</p>
                    <div class="restaurant-meta">
                        <span>⭐ 4.5</span>
                        <span>20–30 min</span>
                    </div>
                    <a class="order-link"
                       href="${pageContext.request.contextPath}/customer/restaurants">
                        View Menu →
                    </a>
                </div>
            </article>

            <article class="restaurant-card">
                <div class="food-image south-indian">
                    <span>🥘</span>
                </div>
                <div class="restaurant-info">
                    <h3>South Spice</h3>
                    <p>Dosa • Idli • South Indian</p>
                    <div class="restaurant-meta">
                        <span>⭐ 4.4</span>
                        <span>20–35 min</span>
                    </div>
                    <a class="order-link"
                       href="${pageContext.request.contextPath}/customer/restaurants">
                        View Menu →
                    </a>
                </div>
            </article>

        </div>
    </section>

    <!-- Order tracking -->
    <section class="tracking-section">
        <div class="tracking-icon">🛵</div>
        <div class="tracking-content">
            <p class="eyebrow">EVERY ORDER, EVERY STEP</p>
            <h2>Your food journey starts here</h2>
            <p>
                Place your first order and follow its progress
                from restaurant preparation to doorstep delivery.
            </p>
        </div>
        <a href="${pageContext.request.contextPath}/customer/orders"
           class="primary-btn">
            Track My Orders
        </a>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <a href="${pageContext.request.contextPath}/customer/dashboard"
           class="brand footer-brand">
            Food<span>Swift</span>
        </a>
        <p>From Kitchen to Doorstep. Made with ❤️ for food lovers.</p>
        <p>© 2026 FoodSwift. All rights reserved.</p>
    </footer>

</main>
</body>
</html>
