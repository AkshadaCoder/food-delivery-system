
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Create Account | FoodSwift</title>

    <link rel="stylesheet"
          href="${pageContext.request.contextPath}/css/register.css">
</head>

<body>

    <div class="register-container">

        <div class="register-card">

            <!-- Brand -->
            <a href="${pageContext.request.contextPath}/home"
               class="brand">
                Food<span>Swift</span>
            </a>

            <h1>Create Your Account</h1>

            <p class="subtitle">
                Join FoodSwift — From Kitchen to Doorstep.
            </p>

            <!-- Error Message: Duplicate Email or Registration Error -->
            <c:if test="${not empty errorMessage}">
                <div class="error-message" role="alert">
                    <c:out value="${errorMessage}"/>
                </div>
            </c:if>

            <!-- Success Message -->
            <c:if test="${not empty successMessage}">
                <div class="success-message" role="status">
                    <c:out value="${successMessage}"/>
                </div>
            </c:if>

            <!-- Registration Form -->
            <form action="${pageContext.request.contextPath}/auth/register"
                  method="post">

                <!-- CSRF Token for Spring Security -->
                <c:if test="${_csrf ne null}">
                    <input type="hidden"
                           name="${_csrf.parameterName}"
                           value="${_csrf.token}">
                </c:if>

                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text"
                           id="name"
                           name="name"
                           placeholder="Enter your full name"
                           autocomplete="name"
                           required>
                </div>

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email"
                           id="email"
                           name="email"
                           placeholder="Enter your email address"
                           autocomplete="email"
                           required>
                </div>

                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel"
                           id="phone"
                           name="phone"
                           placeholder="Enter 10-digit phone number"
                           pattern="[0-9]{10}"
                           maxlength="10"
                           autocomplete="tel"
                           required>
                </div>

                <!-- Role Selection -->
                <div class="form-group">
                    <label for="role">Register As</label>

                    <select id="role" name="role" required>
                        <option value="" disabled selected>
                            Select your role
                        </option>

                        <option value="USER">
                            User / Customer
                        </option>

                        <option value="RESTAURANT">
                            Restaurant
                        </option>

                        <option value="DELIVERY_AGENT">
                            Delivery Agent
                        </option>
                    </select>

                    <small class="field-hint">
                        Choose the role that matches your account.
                    </small>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password"
                           id="password"
                           name="password"
                           placeholder="Create a password"
                           minlength="8"
                           autocomplete="new-password"
                           required>
                </div>

                <div class="form-group">
                    <label for="confirmPassword">Confirm Password</label>
                    <input type="password"
                           id="confirmPassword"
                           name="confirmPassword"
                           placeholder="Re-enter your password"
                           minlength="8"
                           autocomplete="new-password"
                           required>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="register-button">
                    Create Account <span>→</span>
                </button>

            </form>

            <p class="login-text">
                Already have an account?
                <a href="${pageContext.request.contextPath}/auth/foodlogin">
                    Login
                </a>
            </p>

            <a href="${pageContext.request.contextPath}/home"
               class="back-home">
                ← Back to Home
            </a>

        </div>

        <p class="page-footer">
            © 2026 FoodSwift. Made for food lovers.
        </p>

    </div>

</body>
</html>
```