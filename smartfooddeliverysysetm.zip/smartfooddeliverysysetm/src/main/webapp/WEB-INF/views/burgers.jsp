
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FoodSwift | Burgers</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/burgers.css">
</head>
<body>
<header class="navbar">
    <a class="brand" href="${pageContext.request.contextPath}/customer/dashboard">
        Food<span>Swift</span><small>From Kitchen to Doorstep</small>
    </a>
    <nav>
        <a href="${pageContext.request.contextPath}/customer/dashboard">Home</a>
        <a href="${pageContext.request.contextPath}/customer/cart">🛒 Cart</a>
    </nav>
</header>

<main class="container">
    <section class="category-banner burger-banner">
        <p class="eyebrow">BIG FLAVOUR, BIG HAPPINESS</p>
        <h1>Crazy About Burgers?</h1>
        <p>Freshly prepared burgers for every craving.</p>
    </section>

    <h2>Burger Menu</h2>
    <div class="food-grid">
        <article class="food-card">
            <div class="food-emoji">🍔</div>
            <div class="food-details">
                <h3>Classic Veg Burger</h3>
                <p>Crispy vegetable patty with fresh lettuce.</p>
                <div class="food-bottom"><strong>₹99</strong>
					<form action="${pageContext.request.contextPath}/customer/cart/add"
					      method="post">

					    <input type="hidden" name="${_csrf.parameterName}"
					           value="${_csrf.token}">

					    <input type="hidden" name="foodId" value="1">
					    <input type="hidden" name="foodName" value="Classic Veg Burger">
					    <input type="hidden" name="price" value="99">

					    <button type="submit" class="order-btn">
					        Add to Cart
					    </button>
					</form>
                </div>
            </div>
        </article>
        <article class="food-card">
            <div class="food-emoji">🍔</div>
            <div class="food-details">
                <h3>Cheese Burger</h3>
                <p>Vegetable patty with a delicious cheese slice.</p>
                <div class="food-bottom"><strong>₹129</strong>
					<form action="${pageContext.request.contextPath}/customer/cart/add"
					      method="post">

					    <input type="hidden" name="${_csrf.parameterName}"
					           value="${_csrf.token}">

					    <input type="hidden" name="foodId" value="1">
					    <input type="hidden" name="foodName" value="Cheese Burger">
					    <input type="hidden" name="price" value="129">

					    <button type="submit" class="order-btn">
					        Add to Cart
					    </button>
					</form>
                </div>
            </div>
        </article>
        <article class="food-card">
            <div class="food-emoji">🍔</div>
            <div class="food-details">
                <h3>Paneer Burger</h3>
                <p>Spiced paneer patty with creamy sauce.</p>
                <div class="food-bottom"><strong>₹159</strong>
					<form action="${pageContext.request.contextPath}/customer/cart/add"
					      method="post">

					    <input type="hidden" name="${_csrf.parameterName}"
					           value="${_csrf.token}">

					    <input type="hidden" name="foodId" value="1">
					    <input type="hidden" name="foodName" value="Paneer Burger">
					    <input type="hidden" name="price" value="150">

					    <button type="submit" class="order-btn">
					        Add to Cart
					    </button>
					</form>
                </div>
            </div>
        </article>
        <article class="food-card">
            <div class="food-emoji">🍟</div>
            <div class="food-details">
                <h3>Burger Combo</h3>
                <p>Veg burger served with fries.</p>
                <div class="food-bottom"><strong>₹179</strong>
					<form action="${pageContext.request.contextPath}/customer/cart/add"
					      method="post">

					    <input type="hidden" name="${_csrf.parameterName}"
					           value="${_csrf.token}">

					    <input type="hidden" name="foodId" value="1">
					    <input type="hidden" name="foodName" value="Burger Combo">
					    <input type="hidden" name="price" value="179">

					    <button type="submit" class="order-btn">
					        Add to Cart
					    </button>
					</form>
                </div>
            </div>
        </article>
    </div>
    <a class="back-link" href="${pageContext.request.contextPath}/customer/dashboard">← Back to Dashboard</a>
</main>
</body>
</html>
