
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FoodSwift | South Indian</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/south-indian.css">
</head>
<body>
<header class="navbar">
    <a class="brand" href="${pageContext.request.contextPath}/customer/dashboard">
        Food<span>Swift</span><small>From Kitchen to Doorstep</small>
    </a>
    <nav>
        <a href="${pageContext.request.contextPath}/customer/dashboard">Home</a>
        <a href="${pageContext.request.contextPath}/customer/cart">🛒 Cart</a>
    </nav>
</header>

<main class="container">
    <section class="category-banner south-banner">
        <p class="eyebrow">TRADITIONAL • FRESH • TASTY</p>
        <h1>South Indian Delights</h1>
        <p>Enjoy crispy dosas, soft idlis and more.</p>
    </section>

    <h2>South Indian Menu</h2>
    <div class="food-grid">
        <article class="food-card">
            <div class="food-emoji">🥞</div>
            <div class="food-details">
                <h3>Masala Dosa</h3>
                <p>Crispy dosa with a spiced potato filling.</p>
                <div class="food-bottom"><strong>₹100</strong>
                    <a class="order-btn" href="${pageContext.request.contextPath}/customer/cart">Order Now</a>
                </div>
            </div>
        </article>
        <article class="food-card">
            <div class="food-emoji">🥥</div>
            <div class="food-details">
                <h3>Idli Sambar</h3>
                <p>Soft steamed idlis with sambar and chutney.</p>
                <div class="food-bottom"><strong>₹80</strong>
                    <a class="order-btn" href="${pageContext.request.contextPath}/customer/cart">Order Now</a>
                </div>
            </div>
        </article>
        <article class="food-card">
            <div class="food-emoji">🥞</div>
            <div class="food-details">
                <h3>Plain Dosa</h3>
                <p>Golden, crispy dosa served with chutney.</p>
                <div class="food-bottom"><strong>₹80</strong>
                    <a class="order-btn" href="${pageContext.request.contextPath}/customer/cart">Order Now</a>
                </div>
            </div>
        </article>
        <article class="food-card">
            <div class="food-emoji">🍽️</div>
            <div class="food-details">
                <h3>Onion Uttapam</h3>
                <p>Soft savoury pancake topped with onion.</p>
                <div class="food-bottom"><strong>₹120</strong>
                    <a class="order-btn" href="${pageContext.request.contextPath}/customer/cart">Order Now</a>
                </div>
            </div>
        </article>
    </div>
    <a class="back-link" href="${pageContext.request.contextPath}/customer/dashboard">← Back to Dashboard</a>
</main>
</body>
</html>
