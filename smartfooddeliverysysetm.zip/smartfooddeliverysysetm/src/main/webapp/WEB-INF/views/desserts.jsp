
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FoodSwift | Desserts</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/desserts.css">
</head>
<body>
<header class="navbar">
    <a class="brand" href="${pageContext.request.contextPath}/customer/dashboard">
        Food<span>Swift</span><small>From Kitchen to Doorstep</small>
    </a>
    <nav>
        <a href="${pageContext.request.contextPath}/customer/dashboard">Home</a>
        <a href="${pageContext.request.contextPath}/customer/cart">🛒 Cart</a>
    </nav>
</header>

<main class="container">
    <section class="category-banner dessert-banner">
        <p class="eyebrow">A LITTLE EXTRA HAPPINESS</p>
        <h1>Sweet Treats</h1>
        <p>Make every meal sweeter with your favourite dessert.</p>
    </section>

    <h2>Dessert Menu</h2>
    <div class="food-grid">
        <article class="food-card">
            <div class="food-emoji">🍨</div>
            <div class="food-details">
                <h3>Vanilla Ice Cream</h3>
                <p>Creamy vanilla ice cream served chilled.</p>
                <div class="food-bottom"><strong>₹80</strong>
                    <a class="order-btn" href="${pageContext.request.contextPath}/customer/cart">Order Now</a>
                </div>
            </div>
        </article>
        <article class="food-card">
            <div class="food-emoji">🍫</div>
            <div class="food-details">
                <h3>Chocolate Brownie</h3>
                <p>Rich chocolate brownie with a soft centre.</p>
                <div class="food-bottom"><strong>₹120</strong>
                    <a class="order-btn" href="${pageContext.request.contextPath}/customer/cart">Order Now</a>
                </div>
            </div>
        </article>
        <article class="food-card">
            <div class="food-emoji">🍯</div>
            <div class="food-details">
                <h3>Gulab Jamun</h3>
                <p>Soft milk dumplings soaked in sugar syrup.</p>
                <div class="food-bottom"><strong>₹70</strong>
                    <a class="order-btn" href="${pageContext.request.contextPath}/customer/cart">Order Now</a>
                </div>
            </div>
        </article>
        <article class="food-card">
            <div class="food-emoji">🍰</div>
            <div class="food-details">
                <h3>Chocolate Cake</h3>
                <p>Moist chocolate cake with creamy frosting.</p>
                <div class="food-bottom"><strong>₹150</strong>
                    <a class="order-btn" href="${pageContext.request.contextPath}/customer/cart">Order Now</a>
                </div>
            </div>
        </article>
    </div>
    <a class="back-link" href="${pageContext.request.contextPath}/customer/dashboard">← Back to Dashboard</a>
</main>
</body>
</html>
