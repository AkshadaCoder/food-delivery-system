
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FoodSwift</title>

    		<link rel="stylesheet" href="${pageContext.request.contextPath}/css/index.css">
</head>
<!-- Navigation Bar -->
<header>
    <div class="logo">Food<span>Swift</span></div>

    <nav>
        <a href="/">Home</a>
        <a href="#categories">Categories</a>
        <a href="#features">Why FoodSwift?</a>
        <a href="/auth/foodlogin" class="login-btn">Login</a>
        <a href="/auth/register" class="signup-btn">Sign Up</a>
    </nav>
</header>

<!-- Hero Section -->
<section class="hero">
    <div class="hero-content">
        <div class="tag">YOUR FOOD, YOUR WAY</div>

        <h1>
            Delicious Food,<br>
            Delivered <span>Swiftly.</span>
        </h1>

        <p>
            From your favourite restaurant to your doorstep,
            FoodSwift makes every craving easier to satisfy.
            Discover delicious meals and enjoy a smarter food
            delivery experience.
        </p>

        <a href="/signup" class="primary-btn">
            Get Started →
        </a>
    </div>

    <div class="hero-art">
        <div class="hero-food">🍔</div>

        <div class="delivery-note">
            Food on its way!
            <small>From Kitchen to Doorstep.</small>
        </div>
    </div>
</section>

<!-- Food Categories -->
<section class="section" id="categories">
    <div class="section-heading">
        <h2>What Are You Craving?</h2>
        <p>Something delicious is just around the corner.</p>
    </div>

    <div class="category-grid">
        <div class="category">
            <div class="emoji">🍕</div>
            <h3>Pizza</h3>
            <p>Cheesy and delicious</p>
        </div>

        <div class="category">
            <div class="emoji">🍔</div>
            <h3>Burgers</h3>
            <p>Big flavour, every bite</p>
        </div>

        <div class="category">
            <div class="emoji">🍜</div>
            <h3>Noodles</h3>
            <p>Hot and satisfying</p>
        </div>

        <div class="category">
            <div class="emoji">🍰</div>
            <h3>Desserts</h3>
            <p>A sweet little treat</p>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="section" id="features">
    <div class="section-heading">
        <h2>Why Choose FoodSwift?</h2>
        <p>Designed to make your food ordering experience simple.</p>
    </div>

    <div class="features">
        <div class="feature">
            <div class="emoji">⚡</div>
            <h3>Fast Ordering</h3>
            <p>
                Explore food options and place your order
                through a simple ordering experience.
            </p>
        </div>

        <div class="feature">
            <div class="emoji">📍</div>
            <h3>Live Order Tracking</h3>
            <p>
                Follow your order's progress from preparation
                to delivery as tracking features are integrated.
            </p>
        </div>

        <div class="feature">
            <div class="emoji">🔒</div>
            <h3>Secure Experience</h3>
            <p>
                A platform designed with secure account access
                and a reliable ordering process in mind.
            </p>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section class="cta">
    <h2>Your Next Favourite Meal Awaits!</h2>

    <p>
        Get ready to discover delicious food with FoodSwift.
        From Kitchen to Doorstep.
    </p>

    <a href="/signup" class="primary-btn">
        Sign Up Now →
    </a>
</section>

<!-- Footer -->
<footer>
    <p>© 2026 FoodSwift. From Kitchen to Doorstep.</p>
    <p>Made with love for food lovers.</p>
</footer>

